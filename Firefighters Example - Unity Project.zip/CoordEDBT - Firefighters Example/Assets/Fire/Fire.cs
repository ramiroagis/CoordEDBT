﻿using UnityEngine;

public class Fire : MonoBehaviour
{
    private new ParticleSystem particleSystem;
    private ParticleSystem.EmissionModule emissionModule;
    private ParticleSystem.ShapeModule shapeModule;
    private ParticleSystem.VelocityOverLifetimeModule velocityModule;
    private const int MAX_EMISSION_RATE = 36;
    private const float MAX_RADIUS = 0.34f;
    private const float MAX_VELOCITY_Y_AXIS = 1.2f;
    private const int MAX_HP = 150;
    private int hp = 100;

    void Start()
    {
        particleSystem = GetComponent<ParticleSystem>();
        emissionModule = particleSystem.emission;
        shapeModule = particleSystem.shape;
        velocityModule = particleSystem.velocityOverLifetime;
        InvokeRepeating("GrowFlame", 0, 1);
    }

    void OnParticleCollision(GameObject collider)
    {
        hp--;
        if (hp == 0)
        {
            particleSystem.transform.parent = null;
            particleSystem.Stop();
            Destroy(gameObject, 1f);
        }
    }

    void GrowFlame()
    {
        if (hp < MAX_HP)
        {
            hp += 80;
            if (hp > MAX_HP)
            {
                hp = MAX_HP;
            }
        }
        if (emissionModule.rateOverTime.constant < MAX_EMISSION_RATE)
        {
            float emissionRate = emissionModule.rateOverTime.constant;
            emissionModule.rateOverTime = emissionRate + 1f;
        }
        if (shapeModule.radius < MAX_RADIUS)
        {
            shapeModule.radius = shapeModule.radius + 0.007f;
        }
        if (velocityModule.y.constant < MAX_VELOCITY_Y_AXIS)
        {
            float velocityY = velocityModule.y.constant;
            velocityModule.y = velocityY + 0.025f;
        }
    }

}
