﻿using UnityEngine;
using UnityEngine.AI;
using UnityStandardAssets.Characters.ThirdPerson;

public class AnimationController : MonoBehaviour {

	public NavMeshAgent agent;
	public ThirdPersonCharacter character;
	private bool crouching = false;

	void Start () {
		agent.updateRotation = false;	
	}

	void Update () {
		if (agent.remainingDistance > agent.stoppingDistance) {
			character.Move(agent.desiredVelocity, crouching, false);
		} else {
			character.Move(Vector3.zero, crouching, false);
		}
	}

	public void SetCrouching(bool crouching) {
		this.crouching = crouching;
	}

	public void SetActive(bool active) {
		agent.isStopped = !active;

	}
}
