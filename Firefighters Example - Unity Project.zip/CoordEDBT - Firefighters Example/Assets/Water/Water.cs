﻿using UnityEngine;

public class Water : MonoBehaviour
{
    private float lastCollision;

    void Stop()
    {
        ParticleSystem particleSystem = transform.GetComponent<ParticleSystem>();
        particleSystem.Stop();
        Destroy(gameObject, 3.5f);
    }

    void Awake()
    {
        lastCollision = Time.time;
        InvokeRepeating("CheckFire", 0.5f, 0.5f);
    }

    void CheckFire()
    {
        if (Time.time - lastCollision > 0.5)
            Destroy(gameObject);
    }

    void OnParticleCollision()
    {
        lastCollision = Time.time;
    }
}