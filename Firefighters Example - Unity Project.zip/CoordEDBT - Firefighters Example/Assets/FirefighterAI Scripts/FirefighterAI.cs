﻿using CoordEDBT;
using NPBehave;
using UnityEngine;

public class FirefighterAI : Agent
{
    const string BK_HOME_POSITION = "homePosition";
    const string BK_PATROL_POSITION = "patrolPosition";
    const string BK_RECEIVERS = "receivers";
    const string BK_NEARBY_FIRE = "nearbyFire";
    const string BK_TARGET_FIRE = "targetFire";

    public new AnimationController animation;
    public GameObject water;
    private GameObject waterInstance;

    new void Start()
    {
        SetReceivers();
        animation = GetComponent<AnimationController>();
        base.Start();
    }

    protected override Root CreateBehaviorTree()
    {
        return new Root(blackboard,
            new Service(0.1f, CheckMailbox,
                new Service(0.1f, CheckForFire,
                    new Selector(
                        new RequestHandler("extinguish-fire",
                            new Sequence(
                                new NavMoveTo(GetComponent<UnityEngine.AI.NavMeshAgent>(), BK_TARGET_FIRE, 6f, true),
                                new Action(Douse),
                                new WaitUntilDestroyed(BK_TARGET_FIRE),
                                new Action(StopDousing)
                            )
                        ),
                        new Selector(
                            new BlackboardCondition(BK_NEARBY_FIRE, Operator.IS_SET, Stops.LOWER_PRIORITY_IMMEDIATE_RESTART,
                                new HardRequestSender("extinguish-fire", new Parameter[] { new Parameter(BK_NEARBY_FIRE, BK_TARGET_FIRE) }, BK_RECEIVERS, new CoordEDBT.Condition("True"), 150, 2,
                                    new Sequence(
                                        new Action(Douse),
                                        new WaitUntilDestroyed(BK_NEARBY_FIRE),
                                        new Action(StopDousing)
                                    )
                                )
                            ),
                            new Sequence(
                                new Action(SetRandomPatrolPoint),
                                new NavMoveTo(GetComponent<UnityEngine.AI.NavMeshAgent>(), BK_PATROL_POSITION)
                            )
                        )
                    )
                )
            )
        );
    }

    void CheckForFire()
    {
        Collider[] colliders = Physics.OverlapSphere(transform.position, 6f, 1 << 10);
        if (colliders.Length == 0)
        {
            blackboard.Unset(BK_NEARBY_FIRE);
        }
        else if (colliders.Length > 0)
        {
            System.Array.Sort(colliders, new DistanceComparer(transform));
            if (!blackboard.Isset(BK_NEARBY_FIRE))
            {
                blackboard[BK_NEARBY_FIRE] = colliders[0].gameObject;
            }
            else
            {
                GameObject previousClosest = blackboard.Get<GameObject>(BK_NEARBY_FIRE);
                if (!previousClosest.Equals(colliders[0].gameObject))
                {
                    blackboard[BK_NEARBY_FIRE] = colliders[0].gameObject;
                }
            }
        }
    }

    void Douse()
    {
        GameObject fire = blackboard.Get<GameObject>(BK_TARGET_FIRE);
        if (fire == null)
        {
            fire = blackboard.Get<GameObject>(BK_NEARBY_FIRE);
        }
        if (fire == null)
        {
            return;
        }
        animation.SetCrouching(true);
        transform.LookAt(fire.transform);
        animation.SetActive(false);
        waterInstance = Instantiate(water, new Vector3(transform.position.x, transform.position.y + 0.7f, transform.position.z), Quaternion.Euler(0, transform.eulerAngles.y, 0));
    }

    void StopDousing()
    {
        animation.SetActive(true);
        animation.SetCrouching(false);
        if (waterInstance != null)
        {
            waterInstance.SendMessage("Stop");
        }
    }

    void SetRandomPatrolPoint()
    {
        blackboard[BK_PATROL_POSITION] = new Vector3(UnityEngine.Random.Range(-10, 10), 0.54f, UnityEngine.Random.Range(-10, 10));
    }

    void SetReceivers()
    {
        blackboard[BK_RECEIVERS] = GetReceivers();
    }
}