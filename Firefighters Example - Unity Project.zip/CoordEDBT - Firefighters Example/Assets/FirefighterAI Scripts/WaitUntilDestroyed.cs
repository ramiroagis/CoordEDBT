﻿using NPBehave;
using UnityEngine;

public class WaitUntilDestroyed : Task
{
    private GameObject gameObject;
    private string blackboardKey;

    public WaitUntilDestroyed(string blackboardKey) : base("WaitUntilDestroyed")
    {
        this.blackboardKey = blackboardKey;
    }

    public WaitUntilDestroyed(object o) : base("WaitUntilDestroyed")
    {
        if (o is GameObject)
        {
            gameObject = (GameObject) o;
        }
    }

    protected override void DoStart()
    {
        gameObject = RootNode.Blackboard.Get<GameObject>(blackboardKey);
        Clock.AddTimer(0, -1, CheckGameObject);
    }

    private void CheckGameObject()
    {
        if (gameObject == null)
        {
            RootNode.Blackboard.Unset(blackboardKey);
            Clock.RemoveTimer(CheckGameObject);
            Stopped(true);
        }
    }

    override protected void DoStop()
    {
        Clock.RemoveTimer(CheckGameObject);
        Stopped(false);
    }
}