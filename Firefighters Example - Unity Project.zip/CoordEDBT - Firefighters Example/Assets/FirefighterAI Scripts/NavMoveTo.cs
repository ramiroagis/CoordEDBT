using UnityEngine;

namespace NPBehave
{
    public class NavMoveTo : Task
    {
        private const float DESTINATION_CHANGE_THRESHOLD = 0.0001f;
        private const uint DESTINATION_CHANGE_MAX_CHECKS = 100;
        private UnityEngine.AI.NavMeshAgent agent;
        private string blackboardKey;
        private float tolerance;
        private bool stopOnTolerance;
        private float updateFrequency;
        private float updateVariance;
        private Vector3 lastDestination;
        private float lastDistance;

        public NavMoveTo(UnityEngine.AI.NavMeshAgent agent, string blackboardKey, float tolerance = 1.0f, bool stopOnTolerance = false, float updateFrequency = 0.1f, float updateVariance = 0.025f) : base("NavMoveTo")
        {
            this.agent = agent;
            this.blackboardKey = blackboardKey;
            this.tolerance = tolerance;
            this.stopOnTolerance = stopOnTolerance;
            this.updateFrequency = updateFrequency;
            this.updateVariance = updateVariance;
        }

        protected override void DoStart()
        {
            lastDestination = Vector3.zero;
            lastDistance = 99999999.0f;
            Clock.AddTimer(updateFrequency, updateVariance, -1, OnUpdateTimer);
        }

        protected override void DoStop()
        {
            StopAndCleanUp(false);
        }

        private void OnUpdateTimer()
        {
            MoveToBlackboardKey();
        }

        private void MoveToBlackboardKey()
        {
            object target = Blackboard.Get(blackboardKey);
            if (target == null)
            {
                StopAndCleanUp(false);
                Debug.LogWarning("Target is null");
                return;
            }
            Vector3 destination = Vector3.zero;
            if (target is Transform)
            {
                if (updateFrequency >= 0.0f)
                {
                    destination = ((Transform)target).position;
                }
            }
            else if (target is Vector3)
            {
                destination = (Vector3)target;
            }
            else if (target is GameObject)
            {
                if (((GameObject)target) == null)
                {
                    StopAndCleanUp(true);
                    return;
                }
                else
                    destination = ((GameObject)target).transform.position;
            }
            else
            {
                Debug.LogWarning("NavMoveTo: Blackboard Key '" + this.blackboardKey + "' contained unsupported type '" + target.GetType());
                StopAndCleanUp(false);
                return;
            }
            agent.destination = destination;
            float dist = Vector3.Distance(agent.transform.position, destination);
            bool destinationChanged = (agent.destination - lastDestination).sqrMagnitude > (DESTINATION_CHANGE_THRESHOLD * DESTINATION_CHANGE_THRESHOLD); //(destination - agent.destination).sqrMagnitude > (DESTINATION_CHANGE_THRESHOLD * DESTINATION_CHANGE_THRESHOLD);
            bool distanceChanged = Mathf.Abs(dist - lastDistance) > DESTINATION_CHANGE_THRESHOLD;
            if (dist < this.tolerance)
            {
                if (stopOnTolerance || (!destinationChanged && !distanceChanged))
                {
                    StopAndCleanUp(true);
                    return;
                }
            }
            lastDestination = agent.destination;
            lastDistance = dist;
        }

        private void StopAndCleanUp(bool result)
        {
            Clock.RemoveTimer(OnUpdateTimer);
            agent.destination = agent.transform.position;
            Stopped(result);
        }
    }
}