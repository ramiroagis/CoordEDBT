using UnityEngine;

namespace UnityStandardAssets.Characters.ThirdPerson
{
    [RequireComponent(typeof(ThirdPersonCharacter))]
    public class ThirdPersonUserControl : MonoBehaviour
    {
        public GameObject fire;
        private ThirdPersonCharacter character;
        private new Transform camera;
        private Vector3 cameraForward;
        private Vector3 direction;
        private bool canAct = true;
        private bool crouching = false;

        private void Start()
        {
            camera = Camera.main.transform;
            cameraForward = Vector3.Scale(camera.forward, new Vector3(1, 0, 1)).normalized;
            character = GetComponent<ThirdPersonCharacter>();
        }

        private void FixedUpdate()
        {
            if (!canAct)
            {
                direction = Vector3.zero;
            }
            else if (Input.GetKey(KeyCode.Space))
            {
                canAct = false;
                crouching = true;
                Invoke("LightFire", 0.5f);
                direction = Vector3.zero;
            }
            else
            {
                float h = Input.GetAxis("Horizontal");
                float v = Input.GetAxis("Vertical");
                direction = v * cameraForward + h * camera.right;
            }
            character.Move(direction, crouching, false);
        }

        private void LightFire()
        {
            Instantiate(fire, new Vector3(transform.position.x, 0, transform.position.z) + transform.forward, transform.rotation);
            crouching = false;
            canAct = true;
        }

        void OnParticleCollision(GameObject collider)
        {
            Debug.Log(collider.name);
        }
    }
}
