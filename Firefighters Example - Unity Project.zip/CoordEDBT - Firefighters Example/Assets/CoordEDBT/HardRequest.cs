﻿namespace CoordEDBT
{
    public class HardRequest : Request
    {
        public HardRequest(string type) : base(type)
        {
        }
    }
}