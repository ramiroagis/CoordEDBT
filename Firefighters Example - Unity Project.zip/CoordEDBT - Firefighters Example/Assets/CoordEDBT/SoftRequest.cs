﻿namespace CoordEDBT
{
    public class SoftRequest : Request
    {
        public SoftRequest(string type) : base(type)
        {
        }
    }
}